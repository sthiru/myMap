﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace HackatholonSample
{
    public partial class _Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void UploadButton_Click(object sender, EventArgs e)
        {
            string folderPath = Server.MapPath("~/Data/");
            if (!Directory.Exists(folderPath))
            {
                //If Directory (Folder) does not exists. Create it.
                Directory.CreateDirectory(folderPath);
            }
            string filename = Path.GetFileName(FileUploadControl.FileName);
            if (File.Exists(folderPath + "LocationData.json"))
            {
                File.Delete(folderPath + "LocationData.json");
            }
                FileUploadControl.SaveAs(folderPath + "LocationData.json");
           // lblStatus.Text = Path.GetFileName(FileUploadControl.FileName) + " has been uploaded.";

            Response.Redirect("index.html");

        }
    }
}
