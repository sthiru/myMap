function Request(url, method, parameters) {
    var result;

    var requestData = parameters;

    if (method != undefined && method != "") {
        requestData += "&Method=" + method;
    }

    $.ajax({
        type: "POST",
        data: requestData,
        url: url,
        dataType: "html",
        async: false,
        success: function (data) {
            result = data;
        }
    });

    return result;
}

function RequestAsynch(url, method, parameters, onFinish) {
    var result;

    var requestData = parameters;

    if (method != undefined && method != "") {
        requestData += "&Method=" + method;
    }

    $.ajax({
        type: "POST",
        data: requestData,
        url: url,
        dataType: "html",
        async: true,
        success: function (data) {
            if (onFinish != undefined)
                onFinish(data);
        }
    });
}