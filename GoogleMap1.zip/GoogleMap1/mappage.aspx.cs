﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class mappage : System.Web.UI.Page
{
    public string Data;
    protected void Page_Load(object sender, EventArgs e)
    {
        if(!string.IsNullOrEmpty(Convert.ToString(Session["jsonFile"])))
        {
           Data= File.ReadAllText(Session["jsonFile"].ToString());
        }
        else
        {
            Response.Redirect("map.aspx");
        }
    }
}